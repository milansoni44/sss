<div class="footer">
	<div class="footer-inner">
		<div class="footer-content">
			<span class="bigger-120">
				Horus SSS
				Powered By <a href="<?php echo POWERED_BY_LINK;?>" target="_blank"><span class="blue bolder"><?php echo POWERED_BY;?></span></a>
			</span>
		</div>
	</div>
</div>