
<!--[if !IE]> -->
<!--
	<script src="<?php echo $admin_design_path;?>assets/js/jquery-3.2.1.min.js"></script>
-->
	<script src="<?php echo $admin_design_path;?>assets/js/jquery-2.1.4.min.js"></script>

<!-- <![endif]-->

<script type="text/javascript">
	if('ontouchstart' in document.documentElement)
	{
		document.write("<script src='<?php echo $admin_design_path;?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
	}
</script>

<!--[if IE]>
	<script src="<?php echo $admin_design_path;?>assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->





<script src="<?php echo $admin_design_path;?>assets/js/bootstrap.min.js"></script>

<script src="<?php echo $admin_design_path;?>assets/js/bootstrap-colorpicker.min.js"></script>

<!-- page specific plugin scripts -->
<script src="<?php echo $admin_design_path;?>assets/js/jquery.validate.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery-additional-methods.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery.dataTables.bootstrap.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/buttons.flash.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/buttons.html5.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/buttons.print.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/buttons.colVis.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/dataTables.select.min.js"></script>
<!--<script src="<?php /*echo $admin_design_path;*/?>assets/js/jquery-ui.custom.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/markdown.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/bootstrap-markdown.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/jquery.hotkeys.index.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/bootstrap-wysiwyg.min.js"></script>
<script src="<?php /*echo $admin_design_path;*/?>assets/js/bootbox.js"></script>-->
<script src="<?php echo $admin_design_path;?>assets/js/nicEdit.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/ace-elements.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/ace.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/select2.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/moment.js"></script>
<!-- ace scripts
<script src="<?php echo $admin_design_path;?>assets/js/wizard.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery.maskedinput.min.js"></script>

 -->

<script src="<?php echo $admin_design_path;?>assets/js/bootstrap-datepicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?php echo $admin_design_path;?>assets/js/bootstrap-timepicker.min.js"></script>

<!-- daterangepicker -->
<script src="<?php echo $admin_design_path;?>assets/js/daterangepicker.min.js"></script>

<script src="<?php echo $admin_design_path;?>assets/js/ct_script.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery.gritter.min.js"></script>
<script src="<?php echo $admin_design_path;?>assets/js/jquery.easypiechart.min.js"></script>



<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<!-- page specific plugin scripts
<script src="assets/js/bootbox.js"></script>
<script src="assets/js/jquery.maskedinput.min.js"></script>
<script src="assets/js/select2.min.js"></script>
-->








		